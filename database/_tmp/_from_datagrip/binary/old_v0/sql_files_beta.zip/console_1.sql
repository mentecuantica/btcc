CREATE OR REPLACE FUNCTION getDescendants(parentId INTEGER, maxDepth INTEGER DEFAULT 3)
  RETURNS SETOF t_users_binary AS $$
DECLARE
  result t_users_binary%ROWTYPE;
  parent_depth_level INTEGER;
BEGIN

  SELECT
        depth INTO parent_depth_level
          FROM t_users_binary
            WHERE parent_id = parentId;

  RAISE NOTICE 'Parent depth level is %', parent_depth_level;


  maxDepth:=maxDepth + parent_depth_level;

  RAISE NOTICE 'Relative max depth level is %', maxDepth;


  RETURN QUERY
  WITH RECURSIVE child_nodes AS (
    (
      SELECT
        id,
        parent_id,
        child_id,
        placement,
        refer_id,
        depth
      FROM t_users_binary
      WHERE parent_id = parentId
    )
    UNION
    SELECT
      ub.id,
      ub.parent_id,
      ub.child_id,
      ub.placement,
      ub.refer_id,
      ub.depth
    FROM child_nodes, t_users_binary ub
    WHERE ub.parent_id = child_nodes.child_id

  ) SELECT
      parent_id,
      child_id,
      placement,
      depth :: INT,
      refer_id
    FROM child_nodes WHERE depth <= maxDepth;
END;
$$ LANGUAGE 'plpgsql';