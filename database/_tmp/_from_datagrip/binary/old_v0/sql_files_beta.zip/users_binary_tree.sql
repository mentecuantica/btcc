-- USERS_BINARY_TREE TABLE

CREATE TYPE e_binary_position AS ENUM (
  'L',
  'R',
  'N');


CREATE TABLE public.users_binary_tree (
  id SERIAL PRIMARY KEY NOT NULL ,
  parent_id INTEGER NOT NULL,
  child_id INTEGER NOT NULL,
  placement e_binary_position NOT NULL DEFAULT 'N',
  refer_id INTEGER,
  depth INTEGER
);



ALTER TABLE public.users_binary_tree
ADD CONSTRAINT "unq_child_id" UNIQUE ("child_id"),
ADD CONSTRAINT "unq_child_parent" UNIQUE ("parent_id", "child_id"),
ADD CONSTRAINT "fk" FOREIGN KEY ("parent_id") REFERENCES "public"."users" ("id") ON DELETE CASCADE ON UPDATE CASCADE;
CREATE INDEX "idx_parent_id" ON "public"."users_binary" ("parent_id");
CREATE INDEX "idx_parent_child" ON "public"."users_binary" ("parent_id","child_id");




INSERT INTO public.users_binary_tree ( parent_id, child_id, placement, refer_id, depth) VALUES ( 0, 1, 'N', null, 0);
INSERT INTO public.users_binary_tree ( parent_id, child_id, placement, refer_id, depth) VALUES ( 1, 2, 'L', null, 1);
INSERT INTO public.users_binary_tree ( parent_id, child_id, placement, refer_id, depth) VALUES ( 1, 3, 'R', null, 1);
INSERT INTO public.users_binary_tree ( parent_id, child_id, placement, refer_id, depth) VALUES ( 2, 4, 'L', null, 2);
INSERT INTO public.users_binary_tree ( parent_id, child_id, placement, refer_id, depth) VALUES ( 2, 5, 'R', null, 2);
INSERT INTO public.users_binary_tree ( parent_id, child_id, placement, refer_id, depth) VALUES ( 3, 6, 'R', null, 2);
INSERT INTO public.users_binary_tree ( parent_id, child_id, placement, refer_id, depth) VALUES ( 4, 7, 'L', null, 3);
INSERT INTO public.users_binary_tree ( parent_id, child_id, placement, refer_id, depth) VALUES ( 5, 10, 'L', null, 3);
INSERT INTO public.users_binary_tree ( parent_id, child_id, placement, refer_id, depth) VALUES ( 3, 9, 'L', 0, 3);
INSERT INTO public.users_binary_tree ( parent_id, child_id, placement, refer_id, depth) VALUES ( 5, 11, 'R', 0, 4);