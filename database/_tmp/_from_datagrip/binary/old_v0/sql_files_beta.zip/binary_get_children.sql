
WITH RECURSIVE child_nodes AS (

  (
			SELECT parent_id, child_id, placement, depth FROM t_users_binary WHERE parent_id = 1

	)

	UNION

	SELECT ub.parent_id, ub.child_id, ub.placement, ub.depth
	FROM child_nodes, t_users_binary ub
	WHERE ub.parent_id = child_nodes.child_id

)
SELECT parent_id, child_id, name, placement, depth FROM child_nodes, t_users WHERE child_nodes.child_id=t_users.id AND placement='R' AND depth=2
