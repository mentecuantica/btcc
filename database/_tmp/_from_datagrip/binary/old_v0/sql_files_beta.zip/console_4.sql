CREATE OR REPLACE FUNCTION getDescendants1(parentId INTEGER, maxDepth INTEGER DEFAULT 3)
  RETURNS SETOF users_binary_tree AS $$
DECLARE
  result users_binary_tree%ROWTYPE;
  parent_depth_level INTEGER;
BEGIN

  SELECT
        depth INTO parent_depth_level
          FROM users_binary_tree
            WHERE parent_id = parentId;

  RAISE NOTICE 'Parent depth level is %', parent_depth_level;


  maxDepth:=maxDepth + parent_depth_level;

  RAISE NOTICE 'Relative max depth level is %', maxDepth;


  RETURN QUERY
  WITH RECURSIVE child_nodes AS (
    (
      SELECT
        *
      FROM t_users_binary
      WHERE parent_id = parentId
    )
    UNION
    SELECT
      ub.*
    FROM child_nodes, users_binary_tree ub
    WHERE ub.parent_id = child_nodes.child_id

  ) SELECT
      *
    FROM child_nodes WHERE depth <= maxDepth;
END;
$$ LANGUAGE 'plpgsql';