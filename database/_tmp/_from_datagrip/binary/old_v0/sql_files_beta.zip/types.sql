CREATE TYPE binary_node1 as (parent_id INT, child_id INT, name VARCHAR(255), placement CHAR, depth int);


CREATE TYPE binary_node_nameless1 as (parent_id INT, child_id INT, placement CHAR(1), depth int);
